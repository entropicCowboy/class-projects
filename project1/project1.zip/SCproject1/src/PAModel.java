import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.opencsv.CSVWriter;

public class PAModel {
	/*
	 * Chooses a random node (index) based on weighted probabilities
	 * @param: HashMap<Integer, Integer> numAttachments, the HashMap storing the # of attachments
	 * each node has
	 * @param: int neSum, the sum of nodes and edges currently in the graph
	 * @return: int partner, the node to which the new node will be partnered
	 */
	public static int randSelect
	(HashMap<Integer, Integer> numAttachments, int neSum) {
		int size = numAttachments.size();
		double[] probabilities = new double[size];
		double prob = 0;
		double probSum = 0;
		
		// generate probabilities for each node
		for (int i = 0; i < size; i++) {
			prob = (numAttachments.get(i) + 1.0) / neSum;
			probabilities[i] = prob;
			probSum += prob;
		}
		
		// choose random node with weighted probabilities
		Random r = new Random();
		// according to prof., for some reason probSum should not == 1, so make 
		// sure it's within the range
		double p = r.nextDouble(probSum);
		double cumulativeProb = 0.0;
		int ind = r.nextInt(size);
		
		while (cumulativeProb < p) {
			if (ind == size-1)
				ind = 0;
			cumulativeProb += probabilities[ind];
			ind++;
		}
		return ind;
	}
	
	public static double calcCCE(HashMap<Integer, ArrayList<Integer>> attachments) {
		int oTriplets = 0;
		int cTriplets = 0;
		ArrayList<int[]> triplets = new ArrayList<int[]>();
		
		// iterate through each node
		for (int i = 0; i < attachments.size(); i++) {
			ArrayList<Integer> partners = attachments.get(i);
			int pSize = partners.size();
			// for each partner of node i, see if two of them are connected to each other
			// if yes: closed triplet, if no: open triplet
			for (int j = 0; j < pSize; j++) {
				int jNode = partners.get(j);
				ArrayList<Integer> jPartners = attachments.get(jNode);
				for (int k = j+1; k < pSize; k++) {
					int kNode = partners.get(k);
					if (kNode == i)
						continue;
					int[] a = {i,jNode,kNode};
					// sort to check if triplet has already been counted
					Arrays.sort(a);
					if (!triplets.contains(a)) {
						triplets.add(a);
					}
					// if k and j are also partners, the triplet is closed
					if (jPartners.contains(kNode)) {
						System.out.println("Closed triplet: " + i + " " + jNode + " " + kNode);
						cTriplets++;
					}
					else {
						oTriplets++;
					}
				} // end k loop
			} // end j loop
		} // end i loop
		System.out.println("closed triplets: " + cTriplets);
		System.out.println("open triplets: " + oTriplets);
		return (double) cTriplets / (cTriplets + oTriplets);
	}
	
	/*
	 * A function to convert the data in its current form (Nodes :: # of partners)
	 * to the form needed to create the log-log graph (# of partners :: # of Nodes)
	 * @param: HashMap<Integer,Integer>, a HashMap where key = node ID (0-#steps+1) and 
	 * value = # of partners (degrees)
	 */
	public static void convertData(HashMap<Integer,Integer> numAttachments) {
		int size = numAttachments.size();
		// Create an ArrayList where the index = # of partners, and the value stored
		// at that index is the # of nodes that have that many partners
		ArrayList<Integer> nodesToPartners = new ArrayList<>(size);
		// i = a node's index/ID
		for (int i = 0; i < size; i++) {
			// get how many partners node i has
			int numP = numAttachments.get(i);
			int ntpSize = nodesToPartners.size();
			// ensure the index is accessible
			while (ntpSize++ <= numP) {
				nodesToPartners.add(0);
			}
			// increase the # of nodes that have numP partners by 1
			nodesToPartners.set(numP, nodesToPartners.get(numP)+1);
		}
		String filepath = "./project-1-test-10000.csv";
		writeData(filepath, nodesToPartners);
	}
	
	/*
	 * A function to create a CSV file based on the data returned by paModel
	 * Special thanks to https://www.geeksforgeeks.org/writing-a-csv-file-in-java-using-opencsv/
	 * for providing the tutorial.]
	 * @param: String filePath, dictates where to store the CSV file
	 * @param: ArrayList<Integer> nodesToPartners, where each index represents a #
	 * of partners, and the value at each index is the # of nodes that have i partners
	 */
	public static void writeData(String filePath, ArrayList<Integer> nodesToPartners) {
	    // first create file object for file placed at location
	    // specified by filepath
	    File file = new File(filePath);
	  
	    try {
	        // create FileWriter object with file as parameter
	        FileWriter outputfile = new FileWriter(file);
	  
	        // create CSVWriter object filewriter object as parameter
	        CSVWriter writer = new CSVWriter(outputfile);
	  
	        // create a List which contains String array
	        List<String[]> data = new ArrayList<String[]>();
	        data.add(new String[] {"# of Partners (Degrees)","# of Nodes"});
	        //nodesToPartners stores the # of nodes that have i partners
	        for (int i = 0; i < nodesToPartners.size(); i++) {
	        	Integer numNodes = nodesToPartners.get(i);
	        	// Don't include zero values
	        	if (numNodes != 0) {
	        		data.add(new String[] {i + "", numNodes + ""});
	        	}
	        }
	        writer.writeAll(data);
	  
	        // closing writer connection
	        writer.close();
	    }
	    catch (IOException e) {
	        // Auto-generated catch block
	        e.printStackTrace();
	    }
	}
	
	/*
	 * A preferential attachment model that begins with two connected nodes and generates a new
	 * node (and new connection with a partner) each time step.
	 * @param: int steps, # of time steps
	 */
	public static void paModel(int steps) {
		// stores the partners(v) of a node(k)
		HashMap<Integer, ArrayList<Integer>> attachments = new HashMap<>(steps);
		// stores the # of partners(v) of a node(k)
		HashMap<Integer, Integer> numAttachments = new HashMap<>(steps);

		// initialize the HashMaps with two connected nodes O-O
		attachments.put(0, new ArrayList<Integer>()); 
		attachments.put(1, new ArrayList<Integer>());
		numAttachments.put(0,1);
		numAttachments.put(1,1);
		attachments.get(0).add(1);
		attachments.get(1).add(0);
		
		int numNodes = 2;
		int numEdges = 1;
		
		int newNode;
		int partner;
		for (int i = 0; i < steps; i++) {
			// randomly select partner 
			partner = randSelect(numAttachments, numNodes + numEdges);
			
			// add new node to HashMaps
			newNode = numNodes;
			attachments.put(newNode, new ArrayList<Integer>());
			numAttachments.put(newNode, 0);
			
			// connect new node and partner
			numAttachments.replace(newNode,(numAttachments.get(newNode)+1));
			numAttachments.replace(partner,(numAttachments.get(partner)+1));
			attachments.get(newNode).add(partner);
			attachments.get(partner).add(newNode);
			numEdges++;
			numNodes++;
		} // end i loop
		System.out.println(numAttachments.toString());
		for (int i = 0; i < attachments.size(); i++) {
			System.out.println("node " + i + ": " + attachments.get(i).toString());
		}
		double clusterCE = calcCCE(attachments);
		System.out.println(clusterCE);
		convertData(numAttachments);
	}
	public static void main(String[] args) {
		int steps = 10000;
		paModel(steps);
	}
}