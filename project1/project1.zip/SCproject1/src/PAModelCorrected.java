import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.opencsv.CSVWriter;

/*
 * Class: Social Computing
 * Project 1: Preferential Attachment Model
 * Contributors: Frija Reinert and Sam Haseth
 */
public class PAModelCorrected {
	/*
	 * Chooses a random node (index) based on weighted probabilities
	 * @param: ArrayList<ArrayList<Integer>> partnerList, an ArrayList composed of
	 * ArrayLists with two elements representing a pair of connected nodes (partner)
	 * @return: int, the node to which the new node will be partnered
	 */
	public static int randSelect
	(ArrayList<ArrayList<Integer>> partnerList) {
		int numPartners = partnerList.size();

		// choose random node with weighted probabilities
		Random r = new Random();
		// choose a random set of partners from partnerList
		int p = r.nextInt(numPartners);
		// choose a random node from the set of partners (0 or 1)
		int ind = r.nextInt(2);
		
		return partnerList.get(p).get(ind);
	}
	
	/*
	 * Calculates the cluster coefficient by counting the # of closed and open
	 * triplets. Due to the simplicity of this model, the number will always be zero,
	 * rendering this function essentially useless. However, as we had already created
	 * it before learning this fact, here it shall remain.
	 * @param: HashMap<Integer, ArrayList<Integer>> attachments, a HashMap with an
	 * Integer node ID as its key and an ArrayList of Integer node IDs, that the key
	 * node is partnered with, as its value
	 * @return: double, the cluster coefficient (# of closed triplets / sum of open 
	 * and closed triplets)
	 */
	public static double calcCCE(HashMap<Integer, ArrayList<Integer>> attachments) {
		int oTriplets = 0;
		int cTriplets = 0;
		ArrayList<int[]> triplets = new ArrayList<int[]>();
		
		// iterate through each node
		for (int i = 0; i < attachments.size(); i++) {
			ArrayList<Integer> partners = attachments.get(i);
			int pSize = partners.size();
			// for each partner of node i, see if two of them are connected to each other
			// if yes: closed triplet, if no: open triplet
			for (int j = 0; j < pSize; j++) {
				int jNode = partners.get(j);
				ArrayList<Integer> jPartners = attachments.get(jNode);
				for (int k = j+1; k < pSize; k++) {
					int kNode = partners.get(k);
					if (kNode == i)
						continue;
					int[] a = {i,jNode,kNode};
					// sort to check if triplet has already been counted
					Arrays.sort(a);
					if (!triplets.contains(a)) {
						triplets.add(a);
					}
					// if k and j are also partners, the triplet is closed
					if (jPartners.contains(kNode)) {
						System.out.println("Closed triplet: " + i + " " + jNode + " " + kNode);
						cTriplets++;
					}
					else {
						oTriplets++;
					}
				} // end k loop
			} // end j loop
		} // end i loop
		return (double) cTriplets / (cTriplets + oTriplets);
	}
	
	/*
	 * A function to convert the data in its current form (Nodes :: # of partners)
	 * to the form needed to create the log-log graph (# of partners :: # of Nodes)
	 * @param: HashMap<Integer,Integer> numAttachments, a HashMap where key = 
	 * node ID and value = # of partners (degrees)
	 * @param: int steps, included only to create nice file name
	 */
	public static void convertData(HashMap<Integer,Integer> numAttachments, 
			int steps) {
		int size = numAttachments.size();
		// Create an ArrayList where the index = # of partners, and the value stored
		// at that index is the # of nodes that have that many partners
		ArrayList<Integer> nodesToPartners = new ArrayList<>(size);
		// i = a node's index/ID
		for (int i = 0; i < size; i++) {
			// get how many partners node i has
			int numP = numAttachments.get(i);
			int ntpSize = nodesToPartners.size();
			// ensure the index is accessible
			while (ntpSize++ <= numP) {
				nodesToPartners.add(0);
			}
			// increase the # of nodes that have numP partners by 1
			nodesToPartners.set(numP, nodesToPartners.get(numP)+1);
		}
		String filepath = "./project-1-" + steps + ".csv";
		writeData(filepath, nodesToPartners);
	}
	
	/*
	 * A function to create a CSV file based on the data returned by paModel
	 * Special thanks to GeeksForGeeks
	 * https://www.geeksforgeeks.org/writing-a-csv-file-in-java-using-opencsv/
	 * for providing the tutorial.
	 * @param: String filePath, dictates where to store the CSV file
	 * @param: ArrayList<Integer> nodesToPartners, where each index represents a #
	 * of partners, and the value at each index is the # of nodes that have i partners
	 */
	public static void writeData(String filePath, ArrayList<Integer> nodesToPartners) {
	    // create file object for file placed at location specified by filePath
	    File file = new File(filePath);
	  
	    try {
	        // create FileWriter object with file as parameter
	        FileWriter outputfile = new FileWriter(file);
	  
	        // create CSVWriter object fileWriter object as parameter
	        CSVWriter writer = new CSVWriter(outputfile);
	  
	        // create a List which contains String array
	        List<String[]> data = new ArrayList<String[]>();
	        data.add(new String[] {"# of Partners (Degrees)","# of Nodes"});
	        // nodesToPartners stores the # of nodes that have i partners
	        for (int i = 0; i < nodesToPartners.size(); i++) {
	        	Integer numNodes = nodesToPartners.get(i);
	        	// don't include zero values
	        	if (numNodes != 0) {
	        		data.add(new String[] {i + "", numNodes + ""});
	        	}
	        }
	        writer.writeAll(data);
	  
	        // closing writer connection
	        writer.close();
	    }
	    catch (IOException e) {
	        // auto-generated catch block
	        e.printStackTrace();
	    }
	}
	
	/*
	 * A preferential attachment model that begins with two connected nodes and 
	 * generates a new node (and new connection with a partner) each time step.
	 * @param: int steps, # of time steps
	 */
	public static void paModel(int steps) {
		// stores the partners(v) of a node(k)
		HashMap<Integer, ArrayList<Integer>> attachments = new HashMap<>(steps);
		// stores the # of partners(v) of a node(k)
		HashMap<Integer, Integer> numAttachments = new HashMap<>(steps);
		ArrayList<ArrayList<Integer>> partnerList = new ArrayList<>(steps+1);

		// initialize the HashMaps with two connected nodes O-O
		attachments.put(0, new ArrayList<Integer>()); 
		attachments.put(1, new ArrayList<Integer>());
		numAttachments.put(0,1);
		numAttachments.put(1,1);
		attachments.get(0).add(1);
		attachments.get(1).add(0);
		ArrayList<Integer> partners = new ArrayList<Integer>(2);
		partners.add(0); partners.add(1);
		partnerList.add(partners);
		
		int numNodes = 2;
		
		int newNode;
		int partner;
		for (int i = 0; i < steps; i++) {
			// randomly select partner
			partner = randSelect(partnerList);
			
			// add new node to HashMaps
			newNode = numNodes;
			attachments.put(newNode, new ArrayList<Integer>());
			numAttachments.put(newNode, 0);
			
			// connect new node and partner
			numAttachments.replace(newNode,(numAttachments.get(newNode)+1));
			numAttachments.replace(partner,(numAttachments.get(partner)+1));
			attachments.get(newNode).add(partner);
			attachments.get(partner).add(newNode);
			// add partnered nodes to partnerList using temporary partners list
			partners = new ArrayList<Integer>(2);
			partners.add(newNode); partners.add(partner);
			partnerList.add(partners);
			
			numNodes++;
		} // end i loop
		
		/* Uncomment for descriptive print statements
		System.out.println(numAttachments.toString());
		for (int i = 0; i < attachments.size(); i++) {
			System.out.println("node " + i + ": " + attachments.get(i).toString());
		}
		double clusterCE = calcCCE(attachments);
		System.out.println("CCE: " +clusterCE);
		*/
		convertData(numAttachments, steps);
	}
	public static void main(String[] args) {
		int steps = 10000;
		paModel(steps);
		System.out.println("Done!");
	}
}